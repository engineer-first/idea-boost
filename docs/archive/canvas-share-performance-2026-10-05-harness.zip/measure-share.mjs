import {resolve} from 'node:path'; import {pathToFileURL} from 'node:url'; const {chromium}=await import(pathToFileURL(resolve(process.cwd(),'node_modules/playwright/index.mjs')).href);
import {writeFile} from 'node:fs/promises'; import {loadavg} from 'node:os';
const origin=process.env.MEASURE_ORIGIN||'http://localhost:3044', stage=process.argv[2]||'current', commit=process.argv[3]||'d5edae6';
const checkpoint=process.env.CHECKPOINT||'1-2', noteBase=Number(checkpoint[0])*100;const browser=await chromium.launch();const context=await browser.newContext({viewport:{width:1280,height:720}}); const loadStart=loadavg();
await context.addInitScript(()=>{
window.__delay=0;window.__metrics=[];window.__reads=0;window.__long=[];window.__samples=[];window.__sent=[];
const rect=Element.prototype.getBoundingClientRect;Element.prototype.getBoundingClientRect=function(){if(window.__probe)window.__reads++;return rect.call(this)};
const Native=WebSocket;window.WebSocket=class extends Native{
constructor(...args){if(!String(args[0]).includes('/api/rooms/'))return new Native(...args);super(...args)}
send(data){try{window.__sent.push({type:JSON.parse(data).type,time:performance.now()})}catch{};super.send(data)}
addEventListener(type,listener,...args){if(type!=='message')return super.addEventListener(type,listener,...args);return super.addEventListener(type,event=>{let m;try{m=JSON.parse(event.data)}catch{};
if(m?.type==='snapshot'){
 const own=m.notes.find(n=>n.visibility==='private');if(own){const clones=Array.from({length:100-m.notes.length},(_,i)=>({...own,id:`a1000000-0000-4000-8000-${String(i+1).padStart(12,'0')}`,stackOrder:100+i,content:i%3===0?'比較用の長文付箋。折り返しとgeometry計測負荷を再現します。'.repeat(7):'比較用の短い付箋'}));m={...m,notes:[...m.notes,...clones]};event=new MessageEvent('message',{data:JSON.stringify(m)})}}
if(m&&/note:(drag:result|move:result|share:result)/.test(m.type)&&window.__delay)setTimeout(()=>listener.call(this,event),window.__delay);else listener.call(this,event)},...args)}
};
new PerformanceObserver(list=>window.__long.push(...list.getEntries().map(e=>({start:e.startTime,duration:e.duration})))).observe({entryTypes:['longtask']});
window.addEventListener('pointerdown',e=>{const el=e.target.closest('[data-testid="note-card"]');if(!el)return;window.__probe={id:el.dataset.noteId,el,down:performance.now(),x:e.clientX,y:e.clientY,rect:rect.call(el),start:null};window.__reads=0},true);
window.addEventListener('pointermove',e=>{const p=window.__probe;if(!p||p.start!==null||Math.hypot(e.clientX-p.x,e.clientY-p.y)<4)return;p.start=performance.now();const tick=()=>{if(p.ended)return;const ghost=document.querySelector('[data-testid="private-note-drag-preview"]');const b=rect.call(p.el);if(ghost||Math.abs(b.x-p.rect.x)>.1||Math.abs(b.y-p.rect.y)>.1){window.__samples.push({down:p.down,threshold:p.start,first:performance.now(),duration:performance.now()-p.start,downToPreview:performance.now()-p.down,readsUntilPreview:window.__reads});return}if(performance.now()-p.start<2000)requestAnimationFrame(tick);else window.__samples.push({failed:true})};requestAnimationFrame(tick)},true);
window.addEventListener('pointerup',()=>{if(window.__probe){window.__probe.ended=true;window.__metrics.push({geometryReads:window.__reads})}window.__probe=null},true);
});
const page=await context.newPage();page.setDefaultTimeout(10000);const output=[];
try {
 await page.goto(origin+'/login?next=%2Fdev%2Fverify');await page.getByPlaceholder('メールアドレス').fill('owner@example.test');await page.getByPlaceholder('パスワード').fill('password');await page.getByRole('button',{name:'開発用ユーザーでログイン'}).click();await page.waitForURL('**/dev/verify');
 for(const zoom of (process.env.FULL_MATRIX?[25,100,200]:[100]))for(const delay of (process.env.FULL_MATRIX?[0,150,500]:[0])){
 await page.goto(origin+'/dev/verify');await Promise.all([page.waitForResponse(r=>r.url().endsWith('/api/verification/rooms')&&r.request().method()==='POST'),page.getByRole('button',{name:new RegExp('^'+checkpoint+' ')}).click()]);await page.waitForTimeout(300);const link=page.getByRole('link',{name:'このルームを固定して開く（追従なし）'});await link.waitFor();await page.goto(origin+await link.getAttribute('href'));await page.getByTestId('board-canvas').waitFor();await page.evaluate(()=>document.fonts.ready);await page.getByRole('button',{name:'マイ付箋を開く'}).click();await page.getByRole('button',{name:'ズームを100%に戻す'}).click();await page.waitForTimeout(100);
 const shared=page.locator('[data-testid="board-canvas"] [data-note-id="d1000000-0000-4000-8000-'+String(noteBase+3).padStart(12,'0')+'"]');await page.getByTestId('board-scroller').evaluate(el=>el.dispatchEvent(new WheelEvent('wheel',{deltaX:400,deltaY:-220,clientX:600,clientY:300,bubbles:true,cancelable:true})));await page.waitForTimeout(100);let sbox=await shared.boundingBox();
 if(zoom!==100){await page.getByTestId('board-scroller').evaluate((el,{zoom,x,y})=>el.dispatchEvent(new WheelEvent('wheel',{deltaY:-Math.log(zoom/100)/.002,ctrlKey:true,clientX:x,clientY:y,bubbles:true,cancelable:true})),{zoom,x:sbox.x+sbox.width/2,y:sbox.y+sbox.height/2});await page.waitForTimeout(100)}
 for(const surface of (process.env.RETURN_ONLY?['returning']:['private','returning'])){
  await page.evaluate(delay=>{window.__delay=delay;window.__samples=[];window.__long=[];window.__metrics=[];window.__sent=[]},delay);
  const card=surface==='private'?page.getByTestId('private-notes-toolbar').locator('[data-note-id="d1000000-0000-4000-8000-'+String(noteBase).padStart(12,'0')+'"]'):shared;
  for(let i=0;i<30;i++){
   let b=await card.boundingBox();if(surface==='returning'&&b){await page.getByTestId('board-scroller').evaluate((el,{dx,dy})=>el.dispatchEvent(new WheelEvent('wheel',{deltaX:dx,deltaY:dy,clientX:600,clientY:300,bubbles:true,cancelable:true})),{dx:b.x-560,dy:b.y-276});await page.waitForTimeout(40);b=await card.boundingBox()}if(!b||!b.width)throw Error('Missing card '+surface);
   const x=b.x+b.width*.4,y=b.y+b.height*.4;const hit=await page.evaluate(({x,y})=>document.elementFromPoint(x,y)?.closest('[data-note-id]')?.getAttribute('data-note-id'),{x,y});if(hit!==await card.getAttribute('data-note-id'))throw Error('Incorrect hit '+surface+' '+hit+' '+JSON.stringify(b));await page.mouse.move(x,y);await page.mouse.down();await page.waitForTimeout(40);await page.mouse.move(x+12,y);await page.waitForTimeout(30);
   if(surface==='returning'){const t=await page.getByTestId('private-notes-toolbar').boundingBox();await page.mouse.move(t.x+t.width*.6,t.y+t.height*.4,{steps:8});await page.waitForTimeout(30)}
   if(surface==='returning'){await page.mouse.move(x+12,y,{steps:8});await page.waitForTimeout(30)}await page.keyboard.press('Escape');await page.mouse.up();await page.waitForTimeout(Math.max(delay,40));
  }
  const data=await page.evaluate(()=>({samples:window.__samples,longTasks:window.__long,metrics:window.__metrics,sent:window.__sent}));const times=data.samples.filter(s=>!s.failed).map(s=>s.duration).sort((a,b)=>a-b);
  const result={surface,zoom,delay,count:times.length,p95:times[Math.ceil(times.length*.95)-1],max:times.at(-1),...data};output.push(result);console.log(JSON.stringify({stage,surface,zoom,delay,count:result.count,p95:result.p95,geometryMax:Math.max(...data.metrics.map(m=>m.geometryReads))}));
  await writeFile('/tmp/idea-524-evidence/'+stage+'-measure.json',JSON.stringify({stage,checkpoint,commit,browser:browser.version(),viewport:'1280x720',loadStart,loadEnd:loadavg(),fixture:'100 rendered notes: 9 shared, 91 private (30 long). Only two real notes dragged. ACK delivery delay only.',output},null,2));
 }
 }
}catch(error){await page.screenshot({path:'/tmp/idea-524-evidence/'+stage+'-failed.png'});await writeFile('/tmp/idea-524-evidence/'+stage+'-failure.json',JSON.stringify({stage,commit,error:error.message,output},null,2));throw error}finally{await browser.close()}
