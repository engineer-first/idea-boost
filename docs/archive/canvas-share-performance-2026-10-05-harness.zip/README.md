# 共有境界の再実行harness

リポジトリの依存を準備し、管理された dev:verify を3044/8844で起動。出力先 /tmp/idea-524-evidence を作る。scriptのcwdは対象リポジトリ。

MEASURE_ORIGIN=http://localhost:3044 FULL_MATRIX=1 node /path/to/measure-share.mjs candidate COMMIT
CHECKPOINT=3-2 node /path/to/measure-share.mjs candidate-map COMMIT
node /path/to/demo-final.mjs after-final
node /path/to/lost-ack.mjs after-ack-reconnect

全matrixは1-2。3-2のCHECKPOINTは追加の100%/ACK0条件のみ。操作が不正ならfailで終了し、failure.jsonを出す。
歴史版は別のgit archiveで分離し、同一node_modules・webpack devで起動する。Next起動引数へ--webpackを追加するだけでプロダクトを変更しない。必要なら現行dev-server/verification起動管理だけを移す。測定後は起動元へTERMし、子プロセスと待ち受けの消滅を確認する。

公開fixtureと開発用アカウントのみ。実データの本文/認証値をtraceへ追加しない。ACK配送遅延は全RTTを模擬しない。再接続faultはnative close+合成closeイベントを併用。
