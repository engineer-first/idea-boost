import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const {chromium}=await import(pathToFileURL(resolve(process.cwd(),'node_modules/playwright/index.mjs')).href);
import { readFile,rename } from 'node:fs/promises';
const stage=process.argv[2]??'before',origin=process.env.MEASURE_ORIGIN??'http://localhost:3013';
const source=await readFile('/tmp/idea-boost-523-evidence/measure.mjs','utf8');
const start=source.indexOf('await context.addInitScript(()=>{')+'await context.addInitScript(()=>{'.length;
const end=source.indexOf('\n});\nconst page=',start);
const init='(()=>{'+source.slice(start,end)+'})();';
const browser=await chromium.launch();
try{
const auth=await browser.newContext();const control=await auth.newPage();
await control.goto(origin+'/dev/verify');await control.getByRole('textbox',{name:'メールアドレス'}).fill('owner@example.test');await control.getByRole('button',{name:'開発用ユーザーでログイン'}).click();await control.waitForURL('**/dev/verify');
for(const checkpoint of ['1-2','3-3']){
await control.goto(origin+'/dev/verify');await Promise.all([control.waitForResponse(r=>r.url().endsWith('/api/verification/rooms')&&r.request().method()==='POST'),control.getByRole('button',{name:new RegExp('^'+checkpoint+' ')}).click()]);await control.waitForTimeout(100);
const href=await control.getByRole('link',{name:'このルームを固定して開く（追従なし）'}).getAttribute('href');
const context=await browser.newContext({storageState:await auth.storageState(),viewport:{width:1280,height:720},recordVideo:{dir:'/tmp/idea-boost-523-evidence',size:{width:1280,height:720}}});
await context.addInitScript({content:init});const page=await context.newPage();await page.goto(origin+href);await page.getByTestId('board-canvas').waitFor();await page.addStyleTag({content:'nextjs-portal{display:none}'});await page.waitForTimeout(400);await page.getByRole('button',{name:'ズームを100%に戻す'}).click();await page.waitForTimeout(100);
const nodes=page.locator('[data-testid="board-canvas"] [data-testid="note-card"]');let node;
for(let i=0;i<await nodes.count();i++){const n=nodes.nth(i),b=await n.boundingBox();if(b&&b.x>390&&b.y>250&&b.x+b.width<1180&&b.y+b.height<590){node=n;break;}}
if(!node)throw new Error('No visible note');
await page.evaluate(()=>{window.__delay=500;window.__received=[]});
await page.waitForTimeout(500);
for(let i=0;i<3;i++){const b=await node.boundingBox();const x=b.x+b.width*.4,y=b.y+b.height*.4,d=i%2? -12:12;await page.mouse.move(x,y);await page.mouse.down();await page.waitForTimeout(40);await page.mouse.move(x+d,y);await page.waitForTimeout(10);await page.mouse.move(x+d*2,y);await page.waitForTimeout(600);await page.mouse.up();await page.waitForTimeout(700);}
if(stage==='after'){const results=await page.evaluate(()=>window.__received.filter(m=>m.type==='note:move:result'));if(new Set(results.filter(m=>m.status==='accepted').map(m=>m.operationId)).size!==3||results.some(m=>!['active','accepted'].includes(m.status)))throw Error('demo commit results invalid: '+JSON.stringify(results));}
await page.waitForTimeout(500);const video=page.video();await context.close();await rename(await video.path(),`/tmp/idea-boost-523-evidence/${stage}-${checkpoint}.webm`);console.log(stage,checkpoint,'recorded');
}
}finally{await browser.close();}
