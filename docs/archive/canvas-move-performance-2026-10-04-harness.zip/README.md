# Issue #523 performance harness

Run from the repository root after npm install. Requires Node and Playwright Chromium.

1. Place these scripts under /tmp/idea-boost-523-evidence (mkdir -p first).
2. Start the repository-managed server in a dedicated terminal:
   IDEA_BOOST_VERIFY_APP_PORT=3013 IDEA_BOOST_VERIFY_API_PORT=8793 npm run dev:verify
3. Run: node /tmp/idea-boost-523-evidence/measure.mjs after <source-commit>
4. For baseline df53887, use a separate worktree, set MEASURE_ORIGIN to its owned server URL, and pass before. Never reuse another session's server.
5. Build Storybook with npm run build-storybook and serve storybook-static on 6013 with: node --no-warnings scripts/dev-server.mts -- /tmp/idea-boost-523-evidence/static-server.mjs
   Run: node /tmp/idea-boost-523-evidence/collection.mjs <source-commit> The ZIP includes the static server example.
6. demo.mjs after records the single-note videos. collection-demo.mjs records fixed three-note stories. Map filming alone uses visibility:hidden on the other97 cards for readability, retaining DOM/geometry. Performance collection shows all100 cards.
7. Stop each server you started, including children, and check its listener closes. dev:verify normally has a two-hour deadline.

measure.mjs injects 100 public snapshot display notes; only the original moved note exists in the real DO. Long text every third display clone. All outgoing room messages have FIFO half-RTT delay; incoming move/drag result messages have half-RTT delay. Other broadcasts, HTTP, and HMR are not delayed. This is not whole-network RTT emulation.

collection.mjs uses the production hook with fixed first-three selection and a Storybook fake transport. Start ACK only is delayed; commit is synchronous. It does not test #522 selection or DO persistence.

COLLECTION_RESUME=1 resumes completed collection cases only when the recorded source commit matches. At map200%, click the exposed lower-left note area to avoid the map-width toolbar; the hit-ID guard must pass before each drag.

30 drags per surface/zoom/delay. Pointerdown held40ms, threshold move12px, next move24px after10ms. Preview timing uses first rect change detected in rAF, not GPU presentation. Includes raw timing and long-task data.

Raw JSON may contain generated room/note IDs and public dummy text. Publish only the sanitized numerical trace committed in docs/archive. No auth/session data is serialized by these scripts.

Headless dev measurements are exploratory: physical60Hz, Windows, mouse/trackpad, IME, human observation, fixed background load and release thresholds remain unverified.
