import {createServer} from 'node:http';
import {readFile} from 'node:fs/promises';
import path from 'node:path';
const root=process.cwd()+'/storybook-static';
createServer(async(req,res)=>{try{const pathname=decodeURIComponent(new URL(req.url,'http://127.0.0.1').pathname);let file=path.resolve(root,'.'+pathname);if(!file.startsWith(root+'/')&&file!==root)throw Error();if(file===root||pathname.endsWith('/'))file+='/index.html';const body=await readFile(file);res.setHeader('content-type',({'.html':'text/html','.js':'text/javascript','.css':'text/css','.json':'application/json','.svg':'image/svg+xml','.png':'image/png','.woff2':'font/woff2'})[path.extname(file)]??'application/octet-stream');res.end(body);}catch{res.statusCode=404;res.end();}}).listen(6013,'127.0.0.1');
