import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const {chromium}=await import(pathToFileURL(resolve(process.cwd(),'node_modules/playwright/index.mjs')).href);
import { writeFile } from 'node:fs/promises';
import {loadavg} from 'node:os';
const loadStart=loadavg();
const origin=process.env.MEASURE_ORIGIN??'http://localhost:3013', stage=process.argv[2]??'before';
const browser=await chromium.launch();
try {
const context=await browser.newContext({viewport:{width:1280,height:720}});
await context.addInitScript(()=>{
 const Native=window.WebSocket;
 window.__delay=0;window.__sent=[];window.__received=[];window.__samples=[];window.__long=[];
 window.WebSocket=class extends Native {
 constructor(...a){if(!String(a[0]).includes('/api/rooms/'))return new Native(...a);super(...a);window.__socket=this;}
 send(data){let m;try{m=JSON.parse(data)}catch{};if(m)window.__sent.push({...m,time:performance.now()});
  if(m&&window.__delay) setTimeout(()=>super.send(data),window.__delay/2); else super.send(data);
 }
 addEventListener(type,fn,...rest){if(type==='message'){super.addEventListener(type,event=>{let m;try{m=JSON.parse(event.data)}catch{};window.__received.push({...m,time:performance.now()});
if(m?.type==='snapshot'){
 const source=m.notes.filter(n=>n.visibility==='shared');const count=100-source.length;
 const clones=Array.from({length:count},(_,i)=>({...source[i%source.length],id:`a1000000-0000-4000-8000-${String(i+1).padStart(12,'0')}`,content:i%3===0?'比較用の長文付箋。本文が複数行に折り返され、カードの高さと描画負荷を再現します。'.repeat(4):'比較用の短い付箋',x:source[i%source.length].x,y:source[i%source.length].y,stackOrder:0}));
 m={...m,notes:[...m.notes,...clones]};event=new MessageEvent('message',{data:JSON.stringify(m)});
}
if(m&&/note:(drag:result|move:result)/.test(m.type)&&window.__delay) setTimeout(()=>fn.call(this,event),window.__delay/2);else fn.call(this,event);},...rest);}else super.addEventListener(type,fn,...rest);}
 };
 try {new PerformanceObserver(list=>window.__long.push(...list.getEntries().map(e=>({start:e.startTime,duration:e.duration})))).observe({entryTypes:['longtask']});}catch{}
 window.addEventListener('pointerdown',e=>{const el=e.target.closest('[data-testid="note-card"]');if(!el)return;window.__probe={el,down:performance.now(),x:e.clientX,y:e.clientY,rect:el.getBoundingClientRect(),start:null};},true);
 window.addEventListener('pointermove',e=>{const p=window.__probe;if(!p||p.start!==null||Math.hypot(e.clientX-p.x,e.clientY-p.y)<4)return;p.start=performance.now();const tick=()=>{if(p.ended)return;const b=p.el.getBoundingClientRect();if(Math.abs(b.x-p.rect.x)>.1||Math.abs(b.y-p.rect.y)>.1){window.__samples.push({down:p.down,threshold:p.start,first:performance.now(),duration:performance.now()-p.start,downToPreview:performance.now()-p.down});return;}if(performance.now()-p.start<2000)requestAnimationFrame(tick);else window.__samples.push({failed:true});};requestAnimationFrame(tick);},true);
 window.addEventListener('pointerup',()=>{if(window.__probe)window.__probe.ended=true;window.__probe=null},true);
});
const page=await context.newPage();page.on('pageerror',e=>console.log('PAGE ERROR',e.message));await page.goto(origin+'/dev/verify');await page.getByRole('textbox',{name:'メールアドレス'}).fill('owner@example.test');await page.getByRole('button',{name:'開発用ユーザーでログイン'}).click();await page.waitForURL('**/dev/verify');
const result=[];
for(const checkpoint of ['1-2','3-3'])for(const zoom of [25,100,200])for(const delay of [0,150,500]){
 await page.goto(origin+'/dev/verify');
 const [created]=await Promise.all([page.waitForResponse(r=>r.url().endsWith('/api/verification/rooms')&&r.request().method()==='POST'),page.getByRole('button',{name:new RegExp('^'+checkpoint+' ')}).click()]);const createdBody=await created.json();await page.waitForTimeout(100);
 const fixed=page.getByRole('link',{name:'このルームを固定して開く（追従なし）'});await fixed.waitFor();
 const href=await fixed.getAttribute('href');await page.goto(origin+href);await page.getByTestId('board-canvas').waitFor();await page.addStyleTag({content:'nextjs-portal{display:none}'});await page.waitForTimeout(300);
 await page.getByRole('button',{name:'ズームを100%に戻す'}).click();
 await page.waitForTimeout(50);
 const nodes=page.locator('[data-testid="board-canvas"] [data-testid="note-card"]');
 let node;for(let i=0;i<await nodes.count();i++){const n=nodes.nth(i),b=await n.boundingBox();if(b&&b.x>390&&b.y>250&&b.x+b.width<1180&&b.y+b.height<590){node=n;break;}}
 if(!node){console.log('NO NODE',checkpoint,zoom,delay,await nodes.count(),await nodes.first().boundingBox());result.push({checkpoint,zoom,delay,error:'no visible note at 100%'});continue;}
 const beforeZoom=await node.boundingBox();
 await page.getByTestId('board-scroller').evaluate((el,{zoom,x,y})=>el.dispatchEvent(new WheelEvent('wheel',{deltaY:-Math.log(zoom/100)/.002,ctrlKey:true,clientX:x,clientY:y,bubbles:true,cancelable:true})),{zoom,x:beforeZoom.x+beforeZoom.width*.4,y:beforeZoom.y+beforeZoom.height*.4});
 await page.waitForTimeout(50);
 const actualZoom=parseInt(await page.getByRole('button',{name:'ズームを100%に戻す'}).innerText());
 console.log('START',checkpoint,zoom,actualZoom,delay);
 const id=await node.getAttribute('data-note-id');
 await page.evaluate(delay=>{window.__delay=delay;window.__samples=[];window.__sent=[];window.__received=[];window.__long=[];},delay);
 
 for(let n=0;n<30;n++){
  const box=await node.boundingBox();const x=box.x+box.width*.4,y=box.y+box.height*.4,d=n%2===0?12:-12;
  await page.mouse.move(x,y);await page.mouse.down();await page.waitForTimeout(40);await page.mouse.move(x+d,y);await page.waitForTimeout(10);await page.mouse.move(x+d*2,y);await page.waitForTimeout(delay+100);await page.mouse.up();await page.waitForTimeout(delay+100);
 }
 const data=await page.evaluate(()=>({samples:window.__samples,longTasks:window.__long,sent:window.__sent.filter(m=>m.type.startsWith('note:')),received:window.__received.filter(m=>m.type==='error').slice(-5),results:window.__received.filter(m=>m.type==='note:move:result').map(m=>({operationId:m.operationId,status:m.status,reason:m.reason}))}));
 const durations=data.samples.filter(s=>!s.failed).map(s=>s.duration).sort((a,b)=>a-b);
 if(stage==='after' && (new Set(data.results.filter(m=>m.status==='accepted').map(m=>m.operationId)).size!==30 || data.results.some(m=>!['active','accepted'].includes(m.status))))throw Error('Commit results invalid: '+JSON.stringify(data.results));
 const summary={checkpoint,zoom,actualZoom,delay,count:durations.length,p95:durations[Math.ceil(durations.length*.95)-1],max:durations.at(-1),noteId:id,longTasks:data.longTasks.length,load:100,fixture:'original shared notes plus synthetic public snapshot clones, long text every third clone'};
 result.push({...summary,...data});console.log(JSON.stringify(summary));
 if(zoom===100&&delay===500)await page.screenshot({path:`/tmp/idea-boost-523-evidence/${stage}-${checkpoint}-delay500.png`});
 await writeFile(`/tmp/idea-boost-523-evidence/${stage}-measure.json`,JSON.stringify({stage,loadStart,loadEnd:loadavg(),commit:process.argv[3]??'df53887',browser:browser.version(),os:'macOS 26.1 / Apple M4 / 16GB',viewport:'1280x720',result},null,2));
}
} finally {await browser.close();}
